/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.codehaus.groovy.tools.groovydoc;

import org.codehaus.groovy.groovydoc.GroovyClassDoc;
import org.codehaus.groovy.groovydoc.GroovyExecutableMemberDoc;
import org.codehaus.groovy.groovydoc.GroovyParameter;
import org.codehaus.groovy.groovydoc.GroovyType;

import java.util.ArrayList;
import java.util.List;

/**
 * Base implementation for executable members such as methods and constructors.
 */
public class SimpleGroovyExecutableMemberDoc extends SimpleGroovyMemberDoc implements GroovyExecutableMemberDoc {
    private static final GroovyParameter[] EMPTY_GROOVYPARAMETER_ARRAY = new GroovyParameter[0];
    /**
     * Parameters declared by this executable member.
     */
    List<GroovyParameter> parameters;

    /**
     * Creates an executable member owned by the supplied class.
     *
     * @param name the executable name
     * @param belongsToClass the declaring class
     */
    public SimpleGroovyExecutableMemberDoc(String name, GroovyClassDoc belongsToClass) {
        super(name, belongsToClass);
        parameters = new ArrayList<>();
    }

    /** {@inheritDoc} */
    @Override
    public GroovyParameter[] parameters() {
        return parameters.toArray(EMPTY_GROOVYPARAMETER_ARRAY);
    }

    /**
     * Adds a parameter to this executable member.
     *
     * @param parameter the parameter to add
     */
    public void add(GroovyParameter parameter) {
        parameters.add(parameter);
    }

    /** {@inheritDoc} */
    @Override
    public String flatSignature() {/*todo*/return null;}
    /** {@inheritDoc} */
    @Override
    public boolean isNative() {/*todo*/return false;}
    /** {@inheritDoc} */
    @Override
    public boolean isSynchronized() {/*todo*/return false;}
    /** {@inheritDoc} */
    @Override
    public boolean isVarArgs() {/*todo*/return false;}
//    public GroovyParamTag[] paramTags() {/*todo*/return null;}
    /** {@inheritDoc} */
    @Override
    public String signature() {/*todo*/return null;}
    /** {@inheritDoc} */
    @Override
    public GroovyClassDoc[] thrownExceptions() {/*todo*/return null;}
    /** {@inheritDoc} */
    @Override
    public GroovyType[] thrownExceptionTypes() {/*todo*/return null;}
//    public GroovyThrowsTag[] throwsTags() {/*todo*/return null;}
//    public GroovyTypeVariable[] typeParameters() {/*todo*/return null;}
//    public GroovyParamTag[] typeParamTags() {/*todo*/return null;}
}
