/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package groovy.yaml;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import groovy.json.JsonDateHandling;
import groovy.json.JsonParserType;
import groovy.json.JsonSlurper;
import org.apache.groovy.yaml.util.YamlConverter;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 *  Represents a YAML parser
 *  <p>
 *  YAML anchors and aliases are not resolved: an alias is returned as a plain string
 *  holding the anchor's name, and a merge key ({@code <<}) is left as a literal entry.
 *  This comes from the Jackson YAML backend and is a deliberate limitation there. The
 *  Processing YAML user guide covers it, along with what to use when a document relies
 *  on anchors.
 *
 *  @since 3.0.0
 */
public class YamlSlurper {
    private final JsonSlurper jsonSlurper;
    private JsonDateHandling dateHandling = JsonDateHandling.STRING;

    /**
     * Creates a YAML parser that produces standard Groovy data structures.
     */
    public YamlSlurper() {
        this.jsonSlurper = new JsonSlurper();
    }

    /**
     * Returns how a date-like string is handled when parsing.
     *
     * @return the current date handling, {@link JsonDateHandling#STRING} by default
     * @see #setDateHandling(JsonDateHandling)
     * @since 6.0.0
     */
    public JsonDateHandling getDateHandling() {
        return dateHandling;
    }

    /**
     * Chooses what a string in full ISO-8601 or JSON-date form becomes, matching the
     * date handling {@link JsonSlurper} offers. The default is {@link JsonDateHandling#STRING}:
     * a date-like string is left as a {@code String}, which is what this slurper has always
     * produced. A date carrying no time, such as {@code "2026-09-04"}, is left as a
     * {@code String} whatever is chosen here.
     * <p>
     * Choosing anything other than {@link JsonDateHandling#STRING} switches the underlying
     * parser to {@link JsonParserType#INDEX_OVERLAY} so the conversion takes effect; as a
     * consequence, the iteration order of a map with more than a handful of entries is no
     * longer the document order. Pass {@code null} or {@link JsonDateHandling#STRING} to
     * restore the default parser and string handling.
     *
     * @param dateHandling what a date-like string should become
     * @return this slurper, for chaining
     * @since 6.0.0
     */
    public YamlSlurper setDateHandling(JsonDateHandling dateHandling) {
        this.dateHandling = dateHandling == null ? JsonDateHandling.STRING : dateHandling;
        if (this.dateHandling == JsonDateHandling.STRING) {
            jsonSlurper.setType(JsonParserType.CHAR_BUFFER);
        } else {
            jsonSlurper.setType(JsonParserType.INDEX_OVERLAY);
            jsonSlurper.setDateHandling(this.dateHandling);
        }
        return this;
    }

    /**
     * Parse the content of the specified yaml into a tree of Nodes.
     *
     * @param yaml the content of yaml
     * @return the root node of the parsed tree of Nodes
     */
    public Object parseText(String yaml) {
        return this.parse(new StringReader(yaml));
    }

    /**
     * Parse the content of the specified reader into a tree of Nodes.
     *
     * @param reader the reader of yaml
     * @return the root node of the parsed tree of Nodes
     */
    public Object parse(Reader reader) {
        return jsonSlurper.parse(new StringReader(YamlConverter.convertYamlToJson(reader)));
    }

    /**
     * Parse the content of the specified reader into a tree of Nodes.
     *
     * @param stream the reader of yaml
     * @return the root node of the parsed tree of Nodes
     */
    public Object parse(InputStream stream) {
        return parse(new InputStreamReader(stream, StandardCharsets.UTF_8));
    }

    /**
     * Parse the content of the specified file into a tree of Nodes.
     *
     * @param file the reader of yaml
     * @return the root node of the parsed tree of Nodes
     */
    public Object parse(File file) throws IOException {
        return parse(file.toPath());
    }

    /**
     * Parse the content of the specified path into a tree of Nodes.
     *
     * @param path the reader of yaml
     * @return the root node of the parsed tree of Nodes
     */
    public Object parse(Path path) throws IOException {
        try (InputStream stream = Files.newInputStream(path)) {
            return parse(new InputStreamReader(stream, StandardCharsets.UTF_8));
        }
    }

    /**
     * Parse the content of the specified YAML text into a typed object using Jackson databinding.
     * Supports {@code @JsonProperty} and {@code @JsonFormat} annotations for
     * property mapping and type conversion.
     *
     * @param type the target type
     * @param yaml the content of YAML
     * @param <T> the target type
     * @return a typed object
     * @since 6.0.0
     */
    public <T> T parseTextAs(Class<T> type, String yaml) {
        return parseAs(type, new StringReader(yaml));
    }

    /**
     * Parse YAML from a reader into a typed object.
     *
     * @param type the target type
     * @param reader the reader of YAML
     * @param <T> the target type
     * @return a typed object
     * @since 6.0.0
     */
    public <T> T parseAs(Class<T> type, Reader reader) {
        try {
            return mapper(new YAMLFactory()).readValue(reader, type);
        } catch (IOException e) {
            throw new YamlRuntimeException(e);
        }
    }

    static ObjectMapper mapper(YAMLFactory factory) {
        return new ObjectMapper(factory)
                .registerModule(new JavaTimeModule())
                .disable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS)
                .disable(DeserializationFeature.ADJUST_DATES_TO_CONTEXT_TIME_ZONE);
    }

    /**
     * Parse YAML from an input stream into a typed object.
     *
     * @param type the target type
     * @param stream the input stream of YAML
     * @param <T> the target type
     * @return a typed object
     * @since 6.0.0
     */
    public <T> T parseAs(Class<T> type, InputStream stream) {
        return parseAs(type, new InputStreamReader(stream, StandardCharsets.UTF_8));
    }

    /**
     * Parse YAML from a file into a typed object.
     *
     * @param type the target type
     * @param file the YAML file
     * @param <T> the target type
     * @return a typed object
     * @since 6.0.0
     */
    public <T> T parseAs(Class<T> type, File file) throws IOException {
        return parseAs(type, file.toPath());
    }

    /**
     * Parse YAML from a path into a typed object.
     *
     * @param type the target type
     * @param path the path to the YAML file
     * @param <T> the target type
     * @return a typed object
     * @since 6.0.0
     */
    public <T> T parseAs(Class<T> type, Path path) throws IOException {
        try (InputStream stream = Files.newInputStream(path)) {
            return parseAs(type, new InputStreamReader(stream, StandardCharsets.UTF_8));
        }
    }
}
