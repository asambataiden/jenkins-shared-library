/*
 *  Licensed to the Apache Software Foundation (ASF) under one
 *  or more contributor license agreements.  See the NOTICE file
 *  distributed with this work for additional information
 *  regarding copyright ownership.  The ASF licenses this file
 *  to you under the Apache License, Version 2.0 (the
 *  "License"); you may not use this file except in compliance
 *  with the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing,
 *  software distributed under the License is distributed on an
 *  "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 *  KIND, either express or implied.  See the License for the
 *  specific language governing permissions and limitations
 *  under the License.
 */
package org.apache.groovy.json.internal;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static java.lang.System.Logger.Level.WARNING;

/**
 * JVM version helpers used by the JSON parser internals.
 */
class Sys {

    /**
     * Holds the logger so that loading this class does not resolve
     * {@code System.Logger}, a Java 9 API absent from some runtimes built on
     * the JDK class library (Android's ART); the logger is only needed on a
     * failure path (GROOVY-12386).
     */
    private static final class Log {
        static final System.Logger LOGGER = create();

        private static System.Logger create() {
            try {
                return System.getLogger(Sys.class.getName());
            } catch (LinkageError | RuntimeException e) {
                // NoSuchMethodError where the Java 9 logging API is absent; SecurityException in a sandbox
                return null;
            }
        }
    }

    private static final boolean is1_8OrLater;
    private static final boolean is1_7;
    private static final boolean is1_8;

    static {
        BigDecimal v = new BigDecimal("-1");
        String sversion = System.getProperty("java.version");
        if (sversion.contains("_")) {
            final String[] split = sversion.split("_");
            try {
                String ver = split[0];

                if (ver.startsWith("1.7")) {
                    v = new BigDecimal("1.7");
                }

                if (ver.startsWith("1.8")) {
                    v = new BigDecimal("1.8");
                }

                if (ver.startsWith("1.9")) {
                    v = new BigDecimal("1.9");
                }
            } catch (Exception ex) {
                if (Log.LOGGER != null) {
                    Log.LOGGER.log(WARNING, "Unable to determine build number or version", ex);
                }
            }
        } else if ("1.8.0".equals(sversion)) {
            v = new BigDecimal("1.8");
        } else {
            Pattern p = Pattern.compile("^([1-9]\\d*(\\.\\d+)?)");
            Matcher matcher = p.matcher(sversion);
            if (matcher.find()) {
                v = new BigDecimal(matcher.group(0));
            }
        }

        is1_8OrLater = v.compareTo(new BigDecimal("1.8")) >= 0;
        is1_7 = v.compareTo(new BigDecimal("1.7")) == 0;
        is1_8 = v.compareTo(new BigDecimal("1.8")) == 0;
    }

    /**
     * Reports whether the runtime is Java 7 or later.
     *
     * @return always {@code true} on supported runtimes
     */
    public static boolean is1_7OrLater() {
        return true;
    }

    /**
     * Reports whether the runtime is Java 8 or later.
     *
     * @return {@code true} when the detected runtime version is at least 1.8
     */
    public static boolean is1_8OrLater() {
        return is1_8OrLater;
    }

    /**
     * Reports whether the runtime version is Java 7.
     *
     * @return {@code true} when the detected runtime version is 1.7
     */
    public static boolean is1_7() {
        return is1_7;
    }

    /**
     * Reports whether the runtime version is Java 8.
     *
     * @return {@code true} when the detected runtime version is 1.8
     */
    public static boolean is1_8() {
        return is1_8;
    }
}
